#ifndef TABELAS_H
#define TABELAS_H
#include"vetorDes.hpp"
#include"vetorOrd.hpp"
#include"listaDes.hpp"
#include"listaOrd.hpp"
#include"arvoreBin.hpp"
#include"treap.hpp"
#include"arvore23.hpp"
#include"arvoreRN.hpp"
#include"hashTable.hpp"
#endif